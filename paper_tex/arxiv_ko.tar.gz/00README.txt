This paper must be compiled with XeLaTeX (kotex, Noto CJK KR fonts).
